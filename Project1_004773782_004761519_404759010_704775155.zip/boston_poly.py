import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from math import sqrt
from math import log10

import sklearn
from sklearn.preprocessing import normalize
from sklearn.preprocessing import PolynomialFeatures
from sklearn import cross_validation
from sklearn.feature_selection import f_regression
from sklearn import linear_model
from sklearn.cross_validation import KFold


def poly_regression(data,target):
    lr = linear_model.LinearRegression()
    kf = KFold(len(target), n_folds=10, shuffle=True, random_state=None)
    RMSE_POLY = []
    test_times=range(0,10)
    fig=plt.figure()
    for i in range(1,8):
        result=[]
        poly=PolynomialFeatures(degree=i)
        for train_index, test_index in kf:
            data_train, data_test = data[train_index], data[test_index]
            target_train, target_test = target[train_index], target[test_index]
            poly_train=poly.fit_transform(data_train)
            poly_test=poly.fit_transform(data_test)
            lr.fit(poly_train, target_train)
            rmse = log10(sqrt(np.mean((lr.predict(poly_test) - target_test) ** 2)))
            result.append(rmse)
            results=np.mean(result)
        RMSE_POLY.append(results)
        plt.plot(test_times,result,label=('RMSE of Ploynomial Regression--Degree '+str(i)))
    plt.legend(fontsize=8)
    plt.title('Boston Housing Polynomial Regression Model')
    plt.xlabel('Degree')
    plt.ylabel('RMSE')
    plt.ylim(0.0,7)
    plt.savefig('problem4-part3.png')
    plt.show()
    
    return RMSE_POLY

    #scores = cross_validation.cross_val_score(rfr,data_test, target_test.ravel, cv=10)
    #print np.mean(scores)
    
    
    
    

def main():
#    network=pd.read_csv("housing_data.csv",header=None)
    data = pd.read_csv("housing_data.csv",header=None).values[:,:]
    header=['crim','zn','indus','chas','nox','rm','age','dis','rad','tax','ptratio','b','lstat','medv']
    
    target=data[:,13]
    train=data[:,0:13]
    rmse_poly=poly_regression(train,target)
    
    #rmse_l1CV=lassoCV_regression(binaryData,target)

    plt.plot(range(1,8),rmse_poly)
    plt.title('Polynomial Regression RMSE vs Degree')
    plt.xlabel('Degree')
    plt.ylabel('RMSE')
    plt.ylim(0.0,7)
    plt.xlim(0,6)
    plt.savefig('problem4-degree.png',dpi=fig.dpi)
    plt.show()
    
	#print(np.mean(rmse_l1CV))
    
if __name__ == "__main__":
    main()
