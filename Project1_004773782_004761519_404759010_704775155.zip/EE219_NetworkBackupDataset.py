# coding: utf-8

# In[ ]:

# EE 219 Data Mining 
# Project 1: Network Backup Dataset
# Author: Zhengshuang Ren
# Data: Mon, Jan 30
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from math import sqrt
import matplotlib.pyplot as plt

from sklearn import linear_model 
from sklearn import cross_validation
from sklearn.cross_validation import KFold
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import Pipeline

from pybrain.datasets import SupervisedDataSet
from pybrain.tools.shortcuts import buildNetwork
from pybrain.structure import SigmoidLayer, LinearLayer
from pybrain.structure import FeedForwardNetwork
from pybrain.supervised.trainers import BackpropTrainer
from pybrain.structure import FullConnection


# In[ ]:

# Problem 1
# Load data, change Day of week to numerical values, calculate column Day# and Hour#
df = pd.read_csv("network_backup_dataset.csv")
dow_mapping = {'Monday': 1, 'Tuesday': 2, 'Wednesday':3, 'Thursday': 4, 'Friday':5, 'Saturday': 6, 'Sunday': 7}
df = df.replace({'Day of Week': dow_mapping})
df['Day #'] = (df ['Week #'] - 1) * 7 + df['Day of Week']
df['Hour #'] = (df ['Day #'] - 1) * 24 + df['Backup Start Time - Hour of Day']


# In[ ]:

# Seperate 5 different work flows and sum up size of backup for each workflow
wf0 = df[df['Work-Flow-ID' ] == 'work_flow_0']
wf0 = wf0[wf0['Day #'] < 21]
wf1 = df[df['Work-Flow-ID' ] == 'work_flow_1']
wf1 = wf1[wf1['Day #'] < 21]
wf2 = df[df['Work-Flow-ID' ] == 'work_flow_2']
wf2 = wf2[wf2['Day #'] < 21]
wf3 = df[df['Work-Flow-ID' ] == 'work_flow_3']
wf3 = wf3[wf3['Day #'] < 21]
wf4 = df[df['Work-Flow-ID' ] == 'work_flow_4']
wf4 = wf4[wf4['Day #'] < 21]
wf0_g = wf0.groupby('Hour #')
wf0_result = wf0_g.apply(lambda x: x['Size of Backup (GB)'].sum())
wf1_g = wf1.groupby('Hour #')
wf1_result = wf1_g.apply(lambda x: x['Size of Backup (GB)'].sum())
wf2_g = wf2.groupby('Hour #')
wf2_result = wf2_g.apply(lambda x: x['Size of Backup (GB)'].sum())
wf3_g = wf3.groupby('Hour #')
wf3_result = wf3_g.apply(lambda x: x['Size of Backup (GB)'].sum())
wf4_g = wf4.groupby('Hour #')
wf4_result = wf4_g.apply(lambda x: x['Size of Backup (GB)'].sum())


# In[ ]:

# Plot 5 work flow: hours vs. backup size
plt.figure(1)
plt.xlabel('Time(Hours)')
plt.ylabel('Size of Backup(GB)')
plt.title('Work-Flow-0')
plt.plot(wf0_result,color = 'red')
plt.figure(2)
plt.xlabel('Time(Hours)')
plt.ylabel('Size of Backup(GB)')
plt.title('Work-Flow-1')
plt.plot(wf1_result,color = 'red')
plt.figure(3)
plt.xlabel('Time(Hours)')
plt.ylabel('Size of Backup(GB)')
plt.title('Work-Flow-2')
plt.plot(wf2_result,color = 'red')
plt.figure(4)
plt.xlabel('Time(Hours)')
plt.ylabel('Size of Backup(GB)')
plt.title('Work-Flow-3')
plt.plot(wf3_result,color = 'red')
plt.figure(5)
plt.xlabel('Time(Hours)')
plt.ylabel('Size of Backup(GB)')
plt.title('Work-Flow-4')
plt.plot(wf4_result,color = 'red')
plt.show()


# In[ ]:

#Problem 2a 
# change file name, work flow name to numerical value
wf_mapping = {'work_flow_0': 0, 'work_flow_1': 1, 'work_flow_2': 2, 'work_flow_3': 3, 'work_flow_4': 4}
df = df.replace({'Work-Flow-ID': wf_mapping})
fn_mapping = {'File_0': 0, 'File_5': 5, 'File_10': 10, 'File_15': 15, 'File_20': 20, 'File_25': 25, 
              'File_1': 1, 'File_6': 6, 'File_11': 11, 'File_16': 16, 'File_21': 21, 'File_26': 26,  
              'File_2': 2, 'File_7': 7, 'File_12': 12, 'File_17': 17, 'File_22': 22, 'File_27': 27, 
              'File_3': 3, 'File_8': 8, 'File_13': 13, 'File_18': 18, 'File_23': 23, 'File_28': 28, 
              'File_4': 4, 'File_9': 9, 'File_14': 14, 'File_19': 19, 'File_24': 24, 'File_29': 29}
df = df.replace({'File Name': fn_mapping})


# In[ ]:

# Prepare train and target dataset
# Apply linear regression model and cross validation model
train = df.loc[:, ['Week #','Day of Week','Backup Start Time - Hour of Day','Work-Flow-ID', 'File Name','Backup Time (hour)']]
target = df.ix[:,'Size of Backup (GB)']
f10 = KFold(len(train), n_folds=10, shuffle=True, random_state=None)
lr = linear_model.LinearRegression()
#Plot the significance of different variables
plt.figure(6, figsize = (10,6))
frame = plt.gca() 
frame.set_xticklabels( ['Week #','Day of Week','Backup Start Time','Work-Flow-ID','File Name','Backup Time (hour)'])
plt.xlabel('Variables')
plt.ylabel('Coefficient')
plt.title('The Significance of Different Variables')
result = []
trial = 0;
for train_index, test_index in f10:
    x_train, x_test = train.ix[train_index,:], train.ix[test_index,:]
    y_train, y_test = target[train_index], target[test_index]
    lr.fit(x_train,y_train)
    print ('Linear regression accuracy：',lr.score(x_test,y_test))
    rmse = sqrt(np.mean((lr.predict(x_test) - y_test) ** 2))
    result.append(rmse)
    trial = trial + 1
    plt.plot(lr.coef_, 'o', label = 'Trial ' + str(trial)) 
plt.legend(bbox_to_anchor=(1.05, 1),loc = 'Best')
plt.show()
print ('RMSE: ',np.array(result).mean())


# In[ ]:

#Plot 10 trials of cross validation for RMSE
plt.figure(7)
plt.plot(result) 
plt.xlabel('Trial Number')
plt.ylabel('RMSE Value')
plt.title('RMSE for 10-Fold Cross-Validation')
plt.show()


# In[ ]:

# Plot Fitted values and actual values
predicted = lr.predict(train)
tested = pd.DataFrame(predicted, columns = ['Predicted values'])
df_copy = pd.concat([df,tested],axis=1)
plt.figure(8)
df_copy.plot(x=['Hour #'], y=['Size of Backup (GB)','Predicted values'],color=['blue','red'])
plt.xlabel('Time(hours)')
plt.ylabel('Size of Backup (GB)')
plt.title('Fitted values and actual values scattered plot over time')
plt.legend(bbox_to_anchor=(1.05, 1),loc = 'Best')      
plt.show()


# In[ ]:

# Plot
plt.figure(9)
predicted=lr.predict(train)
plt.plot(predicted, predicted - df['Size of Backup (GB)'],'.',color = 'red')
plt.xlabel('Fitted value(GB)')
plt.ylabel('Residuals(GB)')
plt.title('Residuals versus fitted values plot')
plt.figure(9)
plt.plot([-0.1, 0.5],[0 ,0],color='blue')
plt.legend(loc = 'Best')
plt.show()


# In[ ]:

#Problem 2b - Random Forest Regression
#original parameters:
#tree_num = 20
#tree_depth = 4
tree_num = 40
tree_depth = 10

rfr = RandomForestRegressor(n_estimators = tree_num, max_depth = tree_depth, random_state=None)

# Linear and Random forest regression 
lr_result = [] 
rfr_result = []
for train_index, test_index in f10:
    x_train, x_test = train.ix[train_index,:], train.ix[test_index,:]
    y_train, y_test = target[train_index], target[test_index]
    lr.fit(x_train,y_train)
    rfr = rfr.fit(x_train,y_train)
    lr_rmse = sqrt(np.mean((lr.predict(x_test) - y_test) ** 2))
    rfr_rmse = sqrt(np.mean((rfr.predict(x_test) - y_test) ** 2))
    lr_result.append(lr_rmse)
    rfr_result.append(rfr_rmse)
    print ('RFR accuracy: ', rfr.score(x_test,y_test))
    print ('Feature importance:',rfr.feature_importances_)
# LR RMSE versus RFR RMSE
num_trials = range(0,10)
plt.figure(10)
plt.plot(num_trials, lr_result, label = 'LR RMSE')  
plt.plot(num_trials, rfr_result, label = 'RFR RMSE') 
plt.title('LR RMSE vs. RFR RMSE')
plt.xlabel('Number of Trial')
plt.ylabel('RMSE')
plt.legend(bbox_to_anchor=(1.05, 1),loc = 'Best')      
plt.show()
print ('LR RMSE: ', np.array(lr_result).mean() )    
print ('RFR RMSE: ', np.array(rfr_result).mean() ) 


# In[ ]:

# plot actual values and predicted values
plt.figure(11)
plt.plot(y_test, rfr.predict(x_test), '.')
plt.plot(np.linspace(0, 1.2),np.linspace(0, 1.2),'-')
plt.xlabel('Actual value')
plt.ylabel('Predicted value')

# plot feature importance
plt.figure(12)
plt.barh(np.arange(6), rfr.feature_importances_, 0.3, alpha = 0.2, color = 'blue')
plt.title('Feature Importance')
plt.yticks(np.arange(6) + 0.3, train.columns)
plt.xlabel('Importance')
plt.show()


# In[ ]:

#Problem 2.c
ds = SupervisedDataSet(6, 1) #init the training dataset
#Neural network parameters tuning here
in_num = 6
out_num = 1
h1_num = 2
#Build the neural network with 1 hidden layer
nn = FeedForwardNetwork()
in_layer = LinearLayer(in_num)
h1_layer = SigmoidLayer(h1_num)
out_layer = LinearLayer(out_num)
nn.addInputModule(in_layer)
nn.addModule(h1_layer)
nn.addOutputModule(out_layer)
in_h1 = FullConnection(in_layer, h1_layer)
h1_out = FullConnection(h1_layer, out_layer)
nn.addConnection(in_h1)
nn.addConnection(h1_out)
nn.sortModules()


# In[ ]:

#''' #Uncomment this line to skip running the neural network 
result = []
for train_index, test_index in f10:
    x_train, x_test = train.ix[train_index,:], train.ix[test_index,:]
    y_train, y_test = target[train_index], target[test_index]
    for x, y in zip(x_train.values, y_train.values): 
        ds.addSample(tuple(x), y)
    trainer = BackpropTrainer(nn,ds)
    trainer.trainUntilConvergence(maxEpochs = 10)
    print ('Training Neural Network') # To show that the program did not die...
    y_predict = []
    for predict in x_test.values:
        y_predict.append(nn.activate(tuple(predict))[0])
    rmse = sqrt(np.mean((y_predict - y_test) ** 2))
    result.append(rmse)
    ds.clear()
print ('Neural Network RMSE: ', np.array(result).mean() )
#plot predicted value vs real value
plt.figure(13)
plt.plot(y_test, y_predict, 'o')
plt.plot(np.linspace(0, 1.2),np.linspace(0, 1.2),'-')
plt.xlabel('Actual value')
plt.ylabel('Predicted value')
plt.show()
#'''#Uncomment this line to skip running the neural network 


# In[ ]:

#Problem 3
#Seperate Work Flow
wf0 = df[df['Work-Flow-ID' ] == 0]
wf1 = df[df['Work-Flow-ID' ] == 1]
wf2 = df[df['Work-Flow-ID' ] == 2]
wf3 = df[df['Work-Flow-ID' ] == 3]
wf4 = df[df['Work-Flow-ID' ] == 4]

# Apply Linear Regression Model to each work flow 
i=0;
for wf in [wf0, wf1, wf2, wf3, wf4]:
    wf_train = wf.loc[:, ['Week #','Day of Week','Backup Start Time - Hour of Day','Work-Flow-ID', 'File Name','Backup Time (hour)']]
    wf_target = wf.ix[:,'Size of Backup (GB)']
    f10 = KFold(len(wf_train), n_folds=10, shuffle=True, random_state=None)
    lr = linear_model.LinearRegression(fit_intercept=True,normalize=True)
    result = []
    for train_index, test_index in f10:
        x_train, x_test = wf_train.values[train_index,:], wf_train.values[test_index,:]
        y_train, y_test = wf_target.values[train_index], wf_target.values[test_index]
        lr.fit(x_train,y_train)
        rmse = sqrt(np.mean((lr.predict(x_test) - y_test) ** 2))
        result.append(rmse)          
    result = pd.DataFrame(result)
    result[result > 0.5] = 0.5
    plt.figure(14)
    plt.plot(result,label='work_flow_'+ str(i)) 
    print('Average RMSE for work flow ', i, ':',np.array(result).mean()) 
    i = i + 1 
# Plot RMSE for seperate workflow under LR trained model
plt.figure(14)
plt.xlabel('Number of Trial')
plt.ylabel('RMSE')
plt.title('RMSE for seperate workflow under LR trained model')  
plt.legend(bbox_to_anchor=(1.05, 1),loc = 'Best')      
plt.show()


# In[ ]:

# Different degree polynomial model
# Reset all parameters to solve weird issue 
train = df.loc[:, ['Week #','Day of Week','Backup Start Time - Hour of Day','Work-Flow-ID', 'File Name','Backup Time (hour)']]
target = df.ix[:,'Size of Backup (GB)']
lr = linear_model.LinearRegression()
f10 = KFold(len(train), n_folds=10, shuffle=True, random_state=None)
result = []
result_df = []
avg_result=[]

for degree in range(2,8) :
    model = Pipeline([('poly', PolynomialFeatures(degree=degree)),('linear',lr)])
    result = []
    result_df = []
    for train_index, test_index in f10:
        x_train, x_test = train.values[train_index,:], train.values[test_index,:]
        y_train, y_test = target.values[train_index], target.values[test_index]
        model = model.fit(x_train, y_train)
        print (degree,' degree polynomial model accuracy: ',model.score(x_test,y_test))
        rmse = sqrt(np.mean((model.predict(x_test) - y_test) ** 2))
        result.append(rmse)    
    print  ('RMSE: ', np.array(result).mean() )
    result_df = pd.DataFrame(result)
    result_df[result_df > 0.5] = 0.5
    avg_result.append(np.array(result).mean())
    plt.figure(16)      
    plt.plot(result_df, label = str(degree) + ' degree')
# Plot RMSE for different degree polynomial model    
plt.figure(16) 
plt.xlabel('Number of Trial')
plt.ylabel('RMSE')
plt.title('RMSE for different degree polynomial model')
plt.legend(bbox_to_anchor=(1.05, 1),loc = 'Best')
# Plot Average RMSE of different degree polynomial model - 10 Fold CV
plt.figure(17) 
plt.plot(avg_result)
print (avg_result)
plt.xlabel('Degree')
plt.ylabel('RMSE')
plt.title('Average RMSE of different degree polynomial model - 10 Fold CV')
ax = plt.gca() 
ax.set_xticklabels(['2','3','4','5','6','7'])
plt.show()


# In[ ]:



