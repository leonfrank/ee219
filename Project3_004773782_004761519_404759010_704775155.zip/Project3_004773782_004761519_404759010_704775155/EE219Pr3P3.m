% EE219 Project 3 - Collaborative Filtering - W17
% p3) Precision & Recall & ROC Curve

clc
clear

% Creat the matrix R containing the dataset
dataset = importdata('u.data');
R = zeros(max(dataset(:, 1)), max(dataset(:, 2)));

for i = 1:length(dataset)
    R(dataset(i, 1), dataset(i, 2)) = dataset(i, 3);
end

% change 0 into nan for wnmfrule function
R(R==0) = nan;
N = size(dataset,1);

% 10-fold setup
index_known = find(~isnan(R));
s = RandStream('mt19937ar','Seed',0);% allow this random process reproduced
index=randperm(s,N);
threshold_list = 0:0.1:10;

precision_list = zeros(length(threshold_list),3,10);
recall_list = zeros(length(threshold_list),3,10);
like_list = zeros(length(threshold_list),3,10);
% 10 fold cross validation
for i = 1:10
    % prepare data sets
    test_index = index(( (i-1) * N/10 ) + 1:(i * N/10));
    %train_index = [index(1:((i-1) * N/10))  index((i * N/10 + 1):N)];
    train_data = R;
    train_data(index_known(test_index)) = nan;
    j = 1;
    test_data = zeros(max(dataset(:, 1)),max(dataset(:, 2)));
    test_data(index_known(test_index)) = R(index_known(test_index));
    actual_like = sum(sum(test_data(index_known(test_index)) >= 4));
    for k = [10,50,100]
        % train & predict
        option.dis=false;
        [U,V,numIter,tElapsed,finalResidual] = wnmfrule(train_data,k,option);
        P = U * V;
        predict = zeros(max(dataset(:, 1)),max(dataset(:, 2)));
        predict(index_known(test_index)) = P(index_known(test_index));
        for t = 1:length(threshold_list)
            total_predict = sum(sum(test_data(index_known(test_index))>=4 & predict(index_known(test_index))>=threshold_list(t)));
            predict_like = sum(sum(predict(index_known(test_index)) >= threshold_list(t)));
            % calculate precision & recall
            precision = total_predict/predict_like;
            recall = total_predict/actual_like;
            % store in list
            precision_list(t, j, i) = precision;
            recall_list(t, j, i) = recall;
            like_list(t, j, i) = predict_like;
        end     
        j = j+1;
    end
end

% calculate avg precision and recall
precision_mean = mean(precision_list, 3);
recall_mean = mean(recall_list, 3);

% Area for the ROC curve
j = 1;
area = zeros(1,3);
for k =[10,50,100]
    area(j) = trapz(recall_mean(:,j), precision_mean(:,j));
    j = j+1;
end

% plot ROC curve
figure;
hold on;
k10 = plot(recall_mean(:,1),precision_mean(:,1),'b-s','Linewidth', 1.0);
k50 = plot(recall_mean(:,2),precision_mean(:,2),'m--o','Linewidth', 1.0);
k100 = plot(recall_mean(:,3),precision_mean(:,3),'g-^','Linewidth', 1.0);
hold off;
title('ROC Curve');
xlabel('Recall');
ylabel('Precision');
axis([0 1 0 1]);
legend([k10,k50,k100],('K = 10'),('K = 50'),('K = 100'));

% print areas
fprintf('When k = 10, ROC Area is: %f\n', area(1));
fprintf('When k = 50, ROC Area is: %f\n', area(2));
fprintf('When k = 100, ROC Area is: %f\n', area(3));



