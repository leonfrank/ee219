Title: EE 219 Project 3
Author: Zhengshuang Ren
Date: Feb 27, 2017

This package contains 5 .m files for all five problems in project 3 and their dependencies, 
such as wnmfrule, modified wnmfrule for problem 4, wnmfrule_p4 and other helper functions.
It also contains the data used in this project, u.data

They all can be runed directly in Matlab environment R2013a version, 
except for Problem 5 which contains a crossvalind() built-in function that may require a newer version of Matlab.

Note that some data, figures that you see from the report may not be generated directly by the source code.
In this case, they were captured from the workspace after running the codes manually.

In problem 4, to save run time, I set the option for wnmfrule from 1000 iterations to 500 iterations.
Problem 5 was implemented as a function since it is from a different author in our team.