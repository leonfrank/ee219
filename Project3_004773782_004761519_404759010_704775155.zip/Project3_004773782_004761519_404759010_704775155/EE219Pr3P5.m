function [precision,hit_rate,falsealarm_rate,avg_precision,avg_hit_rate,avg_falsealarm_rate]=problem_5
data=dlmread('u.data','\t');

N_user=943;
N_movie=1682;
indices=crossvalind('Kfold',data(:,1),10);
K=[10,50,100];

%threshold=linspace(0.1,1,10);
Lmax=20;
precision=zeros(Lmax,N_user,3);
recall=zeros(Lmax,N_user,3);
hit_rate=zeros(Lmax,N_user,3);
falsealarm_rate=zeros(Lmax,N_user,3);
%maxDislikes=50;%assume that the maximum film one dislike is 50
threshold=0.4;

for kk=1:3
for i=1:10

    
    train_data=zeros(N_user,N_movie);
    W=zeros(N_user,N_movie);
    for j=1:size(indices,1)
        if indices(j)~=i
            W(data(j,1),data(j,2))=data(j,3);
            train_data(data(j,1),data(j,2))=1;
        end;
    end;
    
    test_data=data(indices==i,:);
    
    [U,V,~,~,finalResidual]=reg_wnmfrule(train_data,W,K(kk),0);
    UV=U*V;
    testActual=zeros(N_user,N_movie);
    testPredict=zeros(N_user,N_movie);
    for j=1:size(test_data,1)
        testActual(test_data(j,1),test_data(j,2))=test_data(j,3);
        testPredict(test_data(j,1),test_data(j,2))=UV(test_data(j,1),test_data(j,2));
    end;
    
    [sorted_testActual,sorted_IDActual]=sort(testActual,2,'descend');
    [sorted_testPredict,sorted_IDPredict]=sort(testPredict,2,'descend');
    for l=1:Lmax
        for j=1:N_user
         index=find(testActual(j,:),l);
         
         tp=length(find((testPredict(j,index)>threshold) &(testActual(j,index)>3)));
         tn=length(find((testPredict(j,index)<=threshold) &(testActual(j,index)<=3)));
          fp=length(find((testPredict(j,index)>threshold) &(testActual(j,index)<=3))); 
          fn=length(find((testPredict(j,index)<=threshold) &(testActual(j,index)>3)));
         
         if tp==0&&fn==0
             
         else
             hit_rate(l,j,kk)=hit_rate(l,j,kk)+tp/(tp+fn);
         end;
          if fp==0&&tn==0
             
         else
             falsealarm_rate(l,j,kk)=falsealarm_rate(l,j,kk)+fp/(fp+fn);
         end;
         if ~(tp==0&&fp==0)
         precision(l,j,kk)=precision(l,j,kk)+tp/(tp+fp);
         end;
        end;
    end;
         %         
%           if (actualnum==0) 
%               continue;
%           end;
%           
%           topL_actual=sorted_IDActual(j,1:min(actualnum,l));
%           topL_predict=sorted_IDPredict(j,1:min(predictnum,l));
%           
%           for m=1:length(topL_predict)
%             if isempty(find(topL_actual==topL_predict(m),1))==1 
%                FP = FP+1;
%             else
%                TP=TP+1;
%             end;
%           end;
%        Likes=Likes+length(topL_actual);
%        %Dislikes=Dislikes+length(union(sorted_IDActual(j,length(topL_actual)+1:actualnum),sorted_IDPredict(l,length(topL_predict)+1:predictnum)));
%        Dislikes=Dislikes+maxDislikes;
%        end;
%        TN=Dislikes-FP;
%        FN=Likes-TP;
%        precision(l,i,kk)=TP/(TP+FP);
%        hit_rate(l,i,kk)=TP/(TP+FN);
%        falsealarm_rate(l,i,kk)=FP/(FP+TN);
         
   end;
end;
avg_precision=sum(precision,2)/(10*N_user);
avg_hit_rate=sum(hit_rate,2)/(10*N_user);
avg_falsealarm_rate=sum(falsealarm_rate,2)/(10*N_user);
Lrange=linspace(1,Lmax,Lmax);

    
plot(avg_falsealarm_rate(:,:,1),avg_hit_rate(:,:,1),avg_falsealarm_rate(:,:,2),avg_hit_rate(:,:,2),avg_falsealarm_rate(:,:,3),avg_hit_rate(:,:,3));
    xlabel('false alarm rate');
    ylabel('hit rate');
    legend(strcat('k=',num2str(K(1))),strcat('k=',num2str(K(2))),strcat('k=',num2str(K(3))));
    title('hit rate vs false alarm rate ');
    fig=gcf;
    saveas(fig,'HvsF.png');
    close(fig);
    
    plot(Lrange,avg_hit_rate(:,:,1),Lrange,avg_hit_rate(:,:,2),Lrange,avg_hit_rate(:,:,3));
    xlabel('L');
    ylabel('hit rate');
    legend(strcat('k=',num2str(K(1))),strcat('k=',num2str(K(2))),strcat('k=',num2str(K(3))));
    title('hit rate vs L ');
    fig=gcf;
    saveas(fig,'HvsL.png');
    close(fig);
    
    plot(Lrange,avg_falsealarm_rate(:,:,1),Lrange,avg_falsealarm_rate(:,:,2),Lrange,avg_falsealarm_rate(:,:,3));
    xlabel('L');
    ylabel('false alarm rate');
    legend(strcat('k=',num2str(K(1))),strcat('k=',num2str(K(2))),strcat('k=',num2str(K(3))));
    title('false alarm rate vs L ');
    fig=gcf;
    saveas(fig,'FvsL.png');
    close(fig);

end
