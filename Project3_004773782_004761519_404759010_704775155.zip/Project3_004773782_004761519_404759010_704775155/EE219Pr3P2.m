% EE219 Project 3 - Collaborative Filtering - W17
% p2) Now test the recommendation system you designed by a "10-fold Cross-validation";
% that is randomly split the data and take 90% of the known ratings for training and the other 10% unknown for testing.

clc
clear

% Creat the matrix R containing the dataset
dataset = importdata('u.data');
R = zeros(max(dataset(:, 1)), max(dataset(:, 2)));

for i = 1:length(dataset)
    R(dataset(i, 1), dataset(i, 2)) = dataset(i, 3);
end

% change 0 into nan for wnmfrule function
R(R==0) = nan;

% 10-fold Cross-validation
N = numel(R) - numel(find(isnan(R)));
index_known = find(~isnan(R));

% Reset the global random number stream to its "factory default" initial settings
% This causes RAND, RANDI, and RANDN to start over, as if in a new MATLAB session
s = RandStream('mt19937ar','Seed',0);
index = randperm(s,N);

% randomly split the data and take 90% of the known ratings for training and the other 10% unknown for testing
err = zeros(10,3);
for i = 1:10
    test_index = index(((i-1) * N/10) + 1:(i * N/10));
    %train_index = [index(1:((i-1) * N/10)) index((i * N/10 + 1):N)];
    train_data = R;
    train_data(index_known(test_index)) = nan;
    j = 1;
    for k = [10,50,100];
        option.dis = false;
        [U, V, numIter, tElapsed, finalResidual] = wnmfrule(train_data, k, option);
        predict = U * V;
        err(i,j) = mean(abs(predict(index_known(test_index)) - R(index_known(test_index))));
        j = j + 1;
    end
end

% error avg, max, min
err_avg = mean(mean(err));
err_max = mean(max(err));
err_min = mean(min(err));

% print result
fprintf('the average error among 10 the tests is: %f\n', err_avg);
fprintf('the highest values of average error among the 10 tests is: %f\n', err_max);
fprintf('the lowest values of average error among the 10 tests is: %f\n', err_min);


