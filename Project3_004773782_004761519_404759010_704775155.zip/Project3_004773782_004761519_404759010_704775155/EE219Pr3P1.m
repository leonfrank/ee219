% EE219 Project 3 - Collaborative Filtering - W17
% p1) Download the dataset with 100k ratings and create a matrix named R containing user ratings with users on rows and movies on columns.
% Note that a lot of the values in the matrix will be missing and only a small fraction of the matrix entries will contain known data points.

clc
clear

% Creat the matrix R containing the dataset
dataset = importdata('u.data');
R = zeros(max(dataset(:, 1)), max(dataset(:, 2)));

for i = 1:length(dataset)
    R(dataset(i, 1), dataset(i, 2)) = dataset(i, 3);
    %W(dataset(i, 1), dataset(i, 2)) = 1;
end

% change 0 into nan for wnmfrule function
R(R==0) = nan;

% factorization and calculating error
option.dis=false;
for k = [10,50,100]
    [U,V,numIter,tElapsed,finalResidual] = wnmfrule(R, k, option);
    fprintf('The total least squared error for k = %d: %f \n', k, finalResidual^2);
end

