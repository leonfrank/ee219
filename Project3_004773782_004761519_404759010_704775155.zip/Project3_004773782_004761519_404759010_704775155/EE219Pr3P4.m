% EE219 Project 3 - Collaborative Filtering - W17
% p4) Error , Precision & Recall & ROC Curve
clc
clear

% Creat the matrix R containing the dataset
dataset = importdata('u.data');
R = zeros(max(dataset(:, 1)), max(dataset(:, 2)));
for i = 1:length(dataset)
    R(dataset(i, 1), dataset(i, 2)) = dataset(i, 3);
end

R(R==0) = nan;
N = size(dataset,1);
W = isnan(R);

R_copy = R;
R_copy(W) = 0;

R_W = R_copy;
R_copy(~W) = 1;
W = (~W).* R_W;

% 10-fold setup
index_known = find(~isnan(R));
s = RandStream('mt19937ar','Seed',0);% allow this random process reproduced
index=randperm(s,N);
threshold_list = 0:0.5:5;

precision_list = zeros(3,length(threshold_list),3,10);
recall_list = zeros(3,length(threshold_list),3,10);
like_list = zeros(3,length(threshold_list),3,10);
error_list = zeros(length(threshold_list),3,10);
for i=1:10
    % prepare data sets
    test_index = index(( (i-1) * N/10 ) + 1:(i * N/10));
    %train_index = [index(1:((i-1) * N/10))  index((i * N/10 + 1):N)];
    train_data = R;
    train_data(index_known(test_index)) = nan;

    test_data = zeros(max(dataset(:, 1)),max(dataset(:, 2)));
    test_data(index_known(test_index)) = R(index_known(test_index));
    actual_like = sum(sum(test_data(index_known(test_index)) >= 4));
    l=1;
    for lambda = [0.01, 0.1, 1]
        j = 1;
        % total number of actual like
        for k = [10,50,100]
             option.dis = false;
             option.alpha=lambda;
             option.lambda=lambda;
             option.iter=500;
             [U,V,numIter,tElapsed,finalResidual] = wnmfrule(train_data,k,option);
             P = W.*(U*V);
             predict = zeros(max(dataset(:, 1)),max(dataset(:, 2)));
             predict(index_known(test_index)) = P(index_known(test_index));
             err = W.*((R_copy - U*V).^2);
             error_list(l,j,i)=sum(err(:));% for differnet lamda,k,and 10validation
             for t = 1:length(threshold_list)
                    total_predict = sum(sum(test_data(index_known(test_index))>=4 & predict(index_known(test_index))>=threshold_list(t)));
                    predict_like = sum(sum(predict(index_known(test_index)) >= threshold_list(t)));
                    % calculate precision & recall
                    precision = total_predict/predict_like;
                    recall = total_predict/actual_like;
                    % store in list
                    precision_list(l, t, j, i) = precision;
                    recall_list(l, t, j, i) = recall;
                    like_list(l, t, j, i) = predict_like;
              end                    
              j = j + 1;
        end     
        l = l + 1;
    end
end

save('p.mat','precision_list');
save('r.mat','recall_list');
save('e.mat','error_list');

% plot figure
precision_mean = mean(precision_list,4);
recall_mean = mean(recall_list,4);
lambda=[0.01, 0.1, 1];
K=[10,50,100];
for i=1:3
    figure(i);
    hold on;
    k10 = plot(recall_mean(1,:,i),precision_mean(1,:,i),'b-s','Linewidth', 1.0);
    k50 = plot(recall_mean(2,:,i),precision_mean(2,:,i),'m--o','Linewidth', 1.0);
    k100 = plot(recall_mean(3,:,i),precision_mean(3,:,i),'g-^','Linewidth', 1.0);
    hold off;
    legend('lambda = 0.01','lambda = 0.1','lambda=1');
    xlabel('Recall');
    ylabel('Precision');
    title(['ROC Curve, K =' num2str(K(i))]);
end
hold off;

title('ROC for different lambda and k');
xlabel('False positive rate');
ylabel('True positive rate');
legend('x = y','k = 10','k = 50','k = 100');
figure(2)
for i=1:3
plot(error_result(i,:,:)');
hold on
end
