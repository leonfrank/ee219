import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os

import fetch_data
class_com=['comp.graphics','comp.os.ms-windows.misc','comp.sys.ibm.pc.hardware','comp.sys.mac.hardware']
class_rec=['rec.autos','rec.motorcycles','rec.sport.baseball','rec.sport.hockey']

'''
classes=os.listdir('../20news-bydate-train/')

'''
fetch_data
	
dir_train="20news-bydate-train"
dir_test="20news-bydate-test"
i=0
class_docs=[]
com_docs=[]
rec_docs=[]
for path,subdirs,files in os.walk(dir_train):
    if (i==0): 
	  classes=subdirs
	  
    else: 
	   class_docs.append(len(files))
	   if (classes[i-1] in class_com):
	        com_docs.append(len(files))
           if (classes[i-1] in class_rec):
	        rec_docs.append(len(files))
    i+=1

i=0
for path,subdirs,files in os.walk(dir_test):
    if (i>0): 
	   class_docs[i-1]+=len(files)
	   if (classes[i-1] in class_com):
	        com_docs[class_com.index(classes[i-1])]+=len(files)
           if (classes[i-1] in class_rec):
	        rec_docs[class_rec.index(classes[i-1])]+=len(files)
    i+=1
   
for i in range(len(class_com)):
    print class_com[i]," ",com_docs[i]
for i in range(len(class_rec)):
    print class_rec[i]," ",rec_docs[i]

bar_width=0.8
plt.bar(np.arange(1,len(classes)+1),class_docs,width=bar_width)
plt.xticks(np.arange(1,len(classes)+1)+bar_width/2,classes,rotation=-45)
plt.title('Number of documents per topic')
plt.xlabel('Topic')
plt.ylabel('# of docs' )
plt.xlim(0,len(classes)+2)
plt.savefig('problem-a-1')
plt.show()
