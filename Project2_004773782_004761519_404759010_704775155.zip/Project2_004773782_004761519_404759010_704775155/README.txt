Title: EE 219 Project 2
Author: Zhengshuang Ren
Date: Feb 15, 2017

Dependencies: see imports in the scripts

The scripts are composed by two different team members.

For parts a & e - j: 
Please refer to EE_219_Project_2_(a&e-j).ipynb for ipython notebook version
Please refer to EE_219_Project_2_(a&e-j).py for python version

For parts b,c,d:
Please refer to partial of problem_b-g.py

The reason is that I used scipy.sparse.linalg.svds to improve the accuracy.
Whereas the other coder used TruncateSVD.
However, I was supposed to be responsible for the later parts (g - j).
To be respectful, I leave the codes from the other coder in this package.