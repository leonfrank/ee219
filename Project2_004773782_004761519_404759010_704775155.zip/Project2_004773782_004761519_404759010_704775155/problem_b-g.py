from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.model_selection import KFold
from nltk.stem import SnowballStemmer
import pandas as pd
import numpy as np
import re
from sklearn.decomposition import TruncatedSVD,PCA
from scipy.sparse.linalg import svds
from sklearn import svm
from sklearn.metrics import roc_curve
from sklearn import metrics
from sklearn.utils import shuffle
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB
stemmer=SnowballStemmer("english")

def truncate(idf):
    svd=TruncatedSVD(n_components=50,random_state=42)
    
    return svd.fit_transform(idf)
#This function plots the ROC
def roc(test,classifier_soft,gam,i):
    probas_ = classifier_soft.predict_proba(X_cv[test])                                    
    fpr, tpr, thresholds = roc_curve(Y_cv[test], probas_[:, 1])
    s1 = 'SVM ROC for Gamma=%f' %  gam 
    s2 = ' & Fold=%d' % i
    s = s1+s2
    plt.plot(fpr, tpr, lw=1, label = s)                                    
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic Example')
    plt.legend(loc="lower right")
    plt.savefig('gamma='+str(gam)+'Fold='+str(i)+'.png')
    plt.show()
    return
	
	
def stemming(doc):
    return map(lambda word: stemmer.stem(word), re.findall('[A-Za-z]+',doc))
Categories=['alt.atheism', 'comp.graphics', 'comp.os.ms-windows.misc', 'comp.sys.ibm.pc.hardware', 'comp.sys.mac.hardware', 'comp.windows.x', 'misc.forsale', 'rec.autos', 'rec.motorcycles', 'rec.sport.baseball', 'rec.sport.hockey', 'sci.crypt', 'sci.electronics', 'sci.med', 'sci.space', 'soc.religion.christian', 'talk.politics.guns', 'talk.politics.mideast', 'talk.politics.misc', 'talk.religion.misc']
Test_Categories=['comp.graphics', 'comp.os.ms-windows.misc', 'comp.sys.ibm.pc.hardware', 'comp.sys.mac.hardware', 'comp.windows.x', 'misc.forsale', 'rec.autos', 'rec.motorcycles', 'rec.sport.baseball', 'rec.sport.hockey']
Target_names=['comp.sys.ibm.pc.hardware', 'comp.sys.mac.hardware', 'misc.forsale', 'soc.religion.christian']
twenty_train=fetch_20newsgroups(subset='train',categories=Categories, shuffle=True, random_state=42)
twenty_test=fetch_20newsgroups(subset='test',categories=Categories, shuffle=True, random_state=42)
'''
train_df=pd.DataFrame(twenty_train.target)
train_df=pd.concat([train_df,pd.DataFrame(twenty_train.data)],axis=1)

train_df.columns=['topic','content']

count=[0]*20
for i in twenty_train.target:
    count[i]+=1
print count

train_df=pd.DataFrame(train_df.groupby(train_df['topic'])['content'].apply(lambda x: "{%s}"%'\n'.join(x)))

count_vect = CountVectorizer(tokenizer=stemming,stop_words='english')'''
tfidf_transformer = TfidfTransformer()

count_vect = CountVectorizer(token_pattern='[A-Za-z]+',stop_words='english')
X_train_counts = count_vect.fit_transform(twenty_train.data)

dict=count_vect.get_feature_names()
print len(dict)
'''
with open('dict.txt',"w") as f:
    for word in dict:
        f.write(word.encode('utf-8')+"\n")
f.close()
'''
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)

for target in Target_names:
    target_topic_idf=np.asarray(X_train_tfidf[twenty_train.target==Categories.index(target)].toarray())
    target_idf_sum=np.sum(target_topic_idf,axis=0)
    top10index=np.argsort(target_idf_sum)[::-1]
    top10index=top10index[:15]
    top10term=[dict[x] for x in top10index]
    print target+":\n"
    print [word.encode('utf-8') for word in top10term]

'''svd=MiniBatchSparsePCA(n_components=50,random_state=42)
comp=np.arange(len(Categories))[np.where(['comp' in topic for topic in Categories])]
rec=np.arange(len(Categories))[np.where(['rec' in topic for topic in Categories])]
X_train=[]
Y_train=[]

print tfidf.shape
print tfidf[0]
for i in comp:
    X_train+=list(tfidf[i])*count[i]
    Y_train+=[[1]]*count[i]
for j in rec:
    Y_train+=[[0]]*count[i]
    X_train+=list(tfidf[j])*count[j]'''

tfidf=truncate(X_train_tfidf)
X_train=[]
Y_train=[]

for i in twenty_train.target:
    if 'comp' in Categories[i]:
	X_train.append(tfidf[i].tolist())
        Y_train+=[1]
    elif 'rec' in Categories[i]:
	X_train.append(tfidf[i].tolist())
	Y_train+=[0]
X_train=np.asarray(X_train)	
Y_train=np.asarray(Y_train)
'''
X_train=np.asarray(tfidf)
Y_train=twenty_train.target
for i in range(0,len(Y_train)):
    if(Y_train[i] <= 3):
        Y_train[i] = 1
    else:
        Y_train[i] = 0'''  
model=svm.SVC(kernel='linear',probability=True)
clf=model.fit(X_train,Y_train)

#preprocess the train features
X_test_counts = count_vect.fit_transform(twenty_test.data)
print X_test_counts.shape
X_test_tfidf = tfidf_transformer.fit_transform(X_test_counts)
tfidf = truncate(X_test_tfidf)

X_test=[]
Y_test=[]
for i in twenty_test.target:
    if 'comp' in Categories[i]:
	X_test.append(tfidf[i].tolist())
        Y_test+=[1]
    elif 'rec' in Categories[i]:
	X_test.append(tfidf[i].tolist())
	Y_test+=[0]
X_test=np.asarray(X_test)	
Y_test=np.asarray(Y_test)
X_test,Y_test=shuffle(X_test,Y_test,random_state=0)
'''
X_test=np.asarray(tfidf)
Y_test=twenty_test.target
for i in range(0,len(Y_test)):
    if(Y_test[i] <= 3):
        Y_test[i] = 1
    else:
        Y_test[i] = 0  
'''
#predict on test set
Y_test_predicted=clf.predict(X_test)
accuracy=np.mean(Y_test==Y_test_predicted)
print 'The accuracy for the model is %f' % accuracy
print '\'1\' is Computer Technology and \'0\' is Recreational Activity'
print "The precision and recall values are:"
print metrics.classification_report(Y_test, Y_test_predicted)
print 'The confusion matrix is as shown below:'
print metrics.confusion_matrix(Y_test, Y_test_predicted)

#Plotting the ROC
svm_proba = clf.predict_proba(X_test)                                    
fpr, tpr, thresholds = roc_curve(Y_test, svm_proba[:, 1])
plt.plot(fpr, tpr, lw=1, label = "SVM ROC")                                    
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic Example')
plt.legend(loc="lower right")
plt.savefig('roc-plot')
plt.show()

cv_twenty=fetch_20newsgroups(subset='all',categories=Categories, shuffle=True, random_state=42)
cv_counts = count_vect.fit_transform(cv_twenty.data)
cv_tfidf = tfidf_transformer.fit_transform(cv_counts)
tfidf = truncate(cv_tfidf)

X_cv=[]
Y_cv=[]
for i in twenty_test.target:
    if 'comp' in Categories[i]:
	X_cv.append(tfidf[i].tolist())
        Y_cv+=[1]
    elif 'rec' in Categories[i]:
	X_cv.append(tfidf[i].tolist())
	Y_cv+=[0] 
X_cv=np.asarray(X_cv)	
Y_cv=np.asarray(Y_cv)
'''
X_cv=np.asarray(tfidf)
Y_cv=cv_twenty.target
for i in range(0,len(Y_cv)):
    if(Y_cv[i] <= 3):
        Y_cv[i] = 1
    else:
        Y_cv[i] = 0  
'''
def soft_margin_svm(alpha):
    kf=KFold(n_splits=5,shuffle=True)
    soft_model = svm.SVC(C = alpha,kernel='linear', probability=True)
    print "*****************************************************************************************"
    print "The value of Gamma is %f" % alpha
    fold=0
    for train_index, test_index in kf.split(X_cv,Y_cv):
        Y_test_predicted = soft_model.fit(X_cv[train_index], Y_cv[train_index]).predict(X_cv[test_index])
        accuracy = np.mean(Y_test_predicted == Y_cv[test_index]) 
        print "The accuracy is %f" % accuracy
        print '\'1\' is Computer Technology and \'0\' is Recreational Activity'
        print "The precision and recall values are:"        
        print metrics.classification_report(Y_cv[test_index], Y_test_predicted)
        print 'The confusion matrix is as shown below:'
        print metrics.confusion_matrix(Y_cv[test_index], Y_test_predicted)
        print 'The ROC Curve is as shown below:'
        roc(test_index,soft_model,alpha,fold+1)
        fold+=1
		
#soft_margin_svm for different C values	
'''	
for i in range(-3,4):
	soft_margin_svm(10**i)
'''
nbCLF=GaussianNB()
nbCLF.fit(X_train,Y_train)
Y_pred_nb = nbCLF.predict(X_test) 
accuracy_nb=np.mean(Y_test==Y_pred_nb)
print 'The accuracy for the model is %f' % accuracy_nb
print '\'1\' is Computer Technology and \'0\' is Recreational Activity'
print "The precision and recall values are:"
print metrics.classification_report(Y_test, Y_pred_nb)
print 'The confusion matrix is as shown below:'
print metrics.confusion_matrix(Y_test, Y_pred_nb)

probas_ = nbCLF.predict_proba(X_test)                                    
fpr, tpr, thresholds = roc_curve(Y_test, probas_[:, 1])
plt.plot(fpr, tpr, lw=1, label = "Naive Bayes ROC")                                    
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic Example')
plt.legend(loc="lower right")
plt.savefig('nb')
plt.show()