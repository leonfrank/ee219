Title: Project 5 - Popularity Prediction on Twitter
Course: EE219
Author: Zhengshuang Ren
Date: March 22, 2017

-Instructions to run:

All problem solutions are defined as python functions.
after compileing the scripts, directly make function calls with proper input parameters
such as input file, tagname or period number (for more details, please refer to the comments in the code)


-Dependencies required to run the code:

import pandas as pd
import numpy as np
import nltk
import json
import math
import string
import datetime, time
import matplotlib.pyplot as plt

import statsmodels.api as sm
from sklearn import linear_model

from sklearn import cross_validation
from sklearn.cross_validation import KFold
from sklearn import linear_model
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import Pipeline
from sklearn import svm

import re
import nltk
from nltk import stem
from nltk.stem.snowball import SnowballStemmer
from nltk.corpus import wordnet as wn
from nltk.corpus import sentiwordnet as swn
from nltk.tokenize import word_tokenize
from operator import attrgetter

from sklearn.decomposition import TruncatedSVD,PCA
from scipy.sparse.linalg import svds
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix,roc_curve,accuracy_score,precision_score,recall_score
import matplotlib.pyplot as plt
from sklearn.naive_bayes import GaussianNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.model_selection import KFold,cross_val_predict
from scipy.sparse import csr_matrix
from sklearn.utils import shuffle

-Reference:

https://marcobonzanini.com/2015/03/09/mining-twitter-data-with-python-part-2/
http://stackoverflow.com/questions/26568722/remove-unicode-emoji-using-re-in-python
http://stackoverflow.com/questions/36257964/i-am-trying-to-tokenize-the-text-json-file-dont-know-why-but-only-the-first




