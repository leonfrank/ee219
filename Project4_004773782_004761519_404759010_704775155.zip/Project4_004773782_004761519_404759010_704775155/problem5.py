from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.neighbors import KNeighborsClassifier,NearestNeighbors
from sklearn.cluster import KMeans
from sklearn.model_selection import KFold
from nltk.stem import SnowballStemmer
import pandas as pd
import numpy as np
import re
from sklearn.decomposition import TruncatedSVD,PCA,NMF
from scipy.sparse.linalg import svds
from sklearn.metrics.cluster import homogeneity_score,completeness_score,adjusted_rand_score,adjusted_mutual_info_score
from sklearn.metrics import roc_curve
from sklearn import metrics
from sklearn.utils import shuffle
import matplotlib.pyplot as plt

stemmer=SnowballStemmer("english")
def correct(predict_label,train_label,k):
	majority=[]
	predict_label=np.asarray(predict_label)
	
	for i in range(k):
		count=[0]*6

		cluster_contents=train_label[predict_label==i]
		for content in cluster_contents:
			count[content]+=1
		majority.append(np.argmax(count))
	real_label=[]
	for label in predict_label:
		real_label.append(majority[label])
	return np.asarray(real_label)
	
def stemming(doc):
    return map(lambda word: stemmer.stem(word), re.findall('[A-Za-z0-9]+',doc))
train_1=fetch_20newsgroups(subset='all',shuffle=True, random_state=42)
tfidf_transformer = TfidfTransformer()
classes=['comp','rec','sci','misc.forsale','politics','religion','atheism']
topics=list(train_1.target_names)

count_vect = CountVectorizer(tokenizer=stemming,stop_words='english')
X_train_counts = count_vect.fit_transform(train_1.data)
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
train_label=[]
for i in train_1.target:
	for j in range(0,6): 
		if classes[j] in topics[i]:
			train_label.append(j)
			break;
	if classes[6] in topics[i]:
	    train_label.append(5)
train_label=np.asarray(train_label)
n_features=[2,3,4,5,8,10,15,20,30,50]
n_clusters=[6,8,10,15,20,25,30,40]
'''
for d in n_features:
	svd=TruncatedSVD(n_components=d)
	nmf=NMF(n_components=d)
	svd_idf=svd.fit_transform(X_train_tfidf)
	nmf_idf=nmf.fit_transform(X_train_tfidf)
	for k in range(2,10):
		knn=KMeans(n_clusters=k)
		svd_label=knn.fit_predict(svd_idf)
		nmf_label=knn.fit_predict(nmf_idf)
		svd_label=correct(svd_label,train_label,k)
		nmf_label=correct(nmf_label,train_label,k)
		h_score=homogeneity_score(train_label,svd_label)
		c_score=completeness_score(train_label,svd_label)
		r_score=adjusted_rand_score(train_label,svd_label)
		m_score=adjusted_mutual_info_score(train_label,svd_label)
		print "*****************************************************************************************"
		print 'LSI cluster # = ',k, 'n_components = ',d
		print h_score,c_score,r_score,m_score
		h_score=homogeneity_score(train_label,nmf_label)
		c_score=completeness_score(train_label,nmf_label)
		r_score=adjusted_rand_score(train_label,nmf_label)
		m_score=adjusted_mutual_info_score(train_label,nmf_label)
		
		print 'NMF cluster # = ',k, 'n_components = ',d
		print h_score,c_score,r_score,m_score
'''

svd_measure=np.zeros((4,len(n_clusters)));
nmf_measure=np.zeros((4,len(n_clusters)));
writer1=pd.ExcelWriter('svd_6.xlsx',engine='openpyxl')
writer2=pd.ExcelWriter('nmf_6.xlsx',engine='openpyxl')
for d in n_features:
    
	sheetName='Sheet'+str(n_features.index(d)+1)
	svd=TruncatedSVD(n_components=d)
	nmf=NMF(n_components=d)
	svd_idf=svd.fit_transform(X_train_tfidf)
	nmf_idf=nmf.fit_transform(X_train_tfidf)
	for k in n_clusters: 
		knn=KMeans(n_clusters=k)
		svd_label=knn.fit_predict(svd_idf)
		nmf_label=knn.fit_predict(nmf_idf)
		h_score=homogeneity_score(train_label,svd_label)
		c_score=completeness_score(train_label,svd_label)
		r_score=adjusted_rand_score(train_label,svd_label)
		m_score=adjusted_mutual_info_score(train_label,svd_label)
		svd_measure[0,n_clusters.index(k)]=h_score;
		svd_measure[1,n_clusters.index(k)]=c_score;
		svd_measure[2,n_clusters.index(k)]=r_score;
		svd_measure[3,n_clusters.index(k)]=m_score;
		h_score=homogeneity_score(train_label,nmf_label)
		c_score=completeness_score(train_label,nmf_label)
		r_score=adjusted_rand_score(train_label,nmf_label)
		m_score=adjusted_mutual_info_score(train_label,nmf_label)
		nmf_measure[0,n_clusters.index(k)]=h_score;
		nmf_measure[1,n_clusters.index(k)]=c_score;
		nmf_measure[2,n_clusters.index(k)]=r_score;
		nmf_measure[3,n_clusters.index(k)]=m_score;
	svd_df=pd.DataFrame(svd_measure);
	svd_df.to_excel(writer1,sheet_name=sheetName,index=False)
	nmf_df=pd.DataFrame(nmf_measure);
	nmf_df.to_excel(writer2,sheet_name=sheetName,index=False)
writer1.save()
writer2.save()

train_label=np.asarray(train_1.target)
writer1=pd.ExcelWriter('svd_20.xlsx',engine='openpyxl')
writer2=pd.ExcelWriter('nmf_20.xlsx',engine='openpyxl')
for d in n_features:
    
	sheetName='Sheet'+str(n_features.index(d)+1)
	svd=TruncatedSVD(n_components=d)
	nmf=NMF(n_components=d)
	svd_idf=svd.fit_transform(X_train_tfidf)
	nmf_idf=nmf.fit_transform(X_train_tfidf)
	for k in n_clusters: 
		knn=KMeans(n_clusters=k)
		svd_label=knn.fit_predict(svd_idf)
		nmf_label=knn.fit_predict(nmf_idf)
		h_score=homogeneity_score(train_label,svd_label)
		c_score=completeness_score(train_label,svd_label)
		r_score=adjusted_rand_score(train_label,svd_label)
		m_score=adjusted_mutual_info_score(train_label,svd_label)
		svd_measure[0,n_clusters.index(k)]=h_score;
		svd_measure[1,n_clusters.index(k)]=c_score;
		svd_measure[2,n_clusters.index(k)]=r_score;
		svd_measure[3,n_clusters.index(k)]=m_score;
		h_score=homogeneity_score(train_label,nmf_label)
		c_score=completeness_score(train_label,nmf_label)
		r_score=adjusted_rand_score(train_label,nmf_label)
		m_score=adjusted_mutual_info_score(train_label,nmf_label)
		nmf_measure[0,n_clusters.index(k)]=h_score;
		nmf_measure[1,n_clusters.index(k)]=c_score;
		nmf_measure[2,n_clusters.index(k)]=r_score;
		nmf_measure[3,n_clusters.index(k)]=m_score;
	svd_df=pd.DataFrame(svd_measure);
	svd_df.to_excel(writer1,sheet_name=sheetName,index=False)
	nmf_df=pd.DataFrame(nmf_measure);
	nmf_df.to_excel(writer2,sheet_name=sheetName,index=False)
writer1.save()
writer2.save()