from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.neighbors import KNeighborsClassifier,NearestNeighbors
from sklearn.cluster import KMeans
from sklearn.model_selection import KFold
from nltk.stem import SnowballStemmer
import pandas as pd
import numpy as np
import re
from sklearn.decomposition import TruncatedSVD,PCA,NMF
from scipy.sparse.linalg import svds
from sklearn.metrics.cluster import homogeneity_score,completeness_score,adjusted_rand_score,adjusted_mutual_info_score
from sklearn.metrics import roc_curve
from sklearn import metrics
from sklearn.utils import shuffle
import matplotlib.pyplot as plt

stemmer=SnowballStemmer("english")
def correct(predict_label,train_label):
	accu_1=np.mean(predict_label==train_label)
	predict_label_rev=1-predict_label
	accu_2=np.mean(predict_label_rev==train_label)
	if (accu_2-accu_1>0.2):
		return predict_label_rev,accu_2
	return predict_label,accu_1
def stemming(doc):
    return map(lambda word: stemmer.stem(word), re.findall('[A-Za-z0-9]+',doc))
def roc(test,classifier_soft,gam,i):
    probas_ = classifier_soft.predict_proba(X_cv[test])                                    
    fpr, tpr, thresholds = roc_curve(Y_cv[test], probas_[:, 1])
    s1 = 'SVM ROC for Gamma=%f' %  gam 
    s2 = ' & Fold=%d' % i
    s = s1+s2
    plt.plot(fpr, tpr, lw=1, label = s)                                    
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic Example')
    plt.legend(loc="lower right")
    plt.savefig('gamma='+str(gam)+'Fold='+str(i)+'.png')
    plt.show()
    return
def non_linear(idf):
	u=np.mean(idf,axis=0)
	s=np.std(idf,axis=0)
	idf[:,0]=(idf[:,0]-u[0])/s[0]
	idf[:,1]=(idf[:,1]-u[1])/s[1]
	return np.log(1+idf)
Categories_1=['comp.graphics', 'comp.os.ms-windows.misc', 'comp.sys.ibm.pc.hardware', 'comp.sys.mac.hardware', 'rec.autos', 'rec.motorcycles', 'rec.sport.baseball', 'rec.sport.hockey']
train_1=fetch_20newsgroups(subset='all',categories=Categories_1, shuffle=True, random_state=42)
tfidf_transformer = TfidfTransformer()

count_vect = CountVectorizer(tokenizer=stemming,stop_words='english')
X_train_counts = count_vect.fit_transform(train_1.data)
X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
train_label=[]
for i in train_1.target:
    if 'comp' in Categories_1[i]:
	    train_label.append(0)
    else:
	    train_label.append(1)
knn=KMeans(n_clusters=2)

predict_label=knn.fit_predict(X_train_tfidf)

#train_label=np.reshape(train_label,(len(train_label),1))
predict_label,accu=correct(predict_label,train_label)

print 'The accuracy is: ', accu

print 'The confusion matrix is as shown below:'
print metrics.confusion_matrix(train_label, predict_label)
h_score=homogeneity_score(train_label,predict_label)
c_score=completeness_score(train_label,predict_label)
r_score=adjusted_rand_score(train_label,predict_label)
m_score=adjusted_mutual_info_score(train_label,predict_label)
print h_score,c_score,r_score,m_score

#we shuffle the tf-dif matrix to see if permutation can change the accuracy 
for t in range(1,10):
	p_train_tfidf,p_train_label=shuffle(X_train_tfidf,train_label,random_state=t)
	p_predict_label=knn.fit_predict(p_train_tfidf)
	p_predict_label,p_accu=correct(p_predict_label,p_train_label)
	print "*****************************************************************************************"
	print t,'th shuffle result'
	print 'The accuracy after permutation is: ',p_accu
	
	
	print 'The confusion matrix is as shown below:'
	print metrics.confusion_matrix(p_train_label, p_predict_label)
	p_h_score=homogeneity_score(p_train_label,p_predict_label)
	p_c_score=completeness_score(p_train_label,p_predict_label)
	p_r_score=adjusted_rand_score(p_train_label,p_predict_label)
	p_m_score=adjusted_mutual_info_score(p_train_label,p_predict_label)
	print p_h_score,p_c_score,p_r_score,p_m_score


n_features=[2,3,5,10,20,50,100,200]
for k in n_features:
	svd=TruncatedSVD(n_components=k)
	truncated_idf=svd.fit_transform(X_train_tfidf)
	predict_label=knn.fit_predict(truncated_idf)
	predict_label,accu=correct(predict_label,train_label)
	print "*****************************************************************************************"
	print 'LSI truncated n_components = ',k
	
	print 'The accuracy is: ', accu

	print 'The confusion matrix is as shown below:'
	print metrics.confusion_matrix(train_label, predict_label)
	h_score=homogeneity_score(train_label,predict_label)
	c_score=completeness_score(train_label,predict_label)
	r_score=adjusted_rand_score(train_label,predict_label)
	m_score=adjusted_mutual_info_score(train_label,predict_label)
	print h_score,c_score,r_score,m_score

for k in n_features:	
	nmf=NMF(n_components=k)
	nmf_idf=nmf.fit_transform(X_train_tfidf)
	predict_label=knn.fit_predict(nmf_idf)
	predict_label,accu=correct(predict_label,train_label)
	print "*****************************************************************************************"
	print 'NMF truncated n_components = ',k
	print 'The accuracy is: ', accu
	print 'The confusion matrix is as shown below:'
	print metrics.confusion_matrix(train_label, predict_label)
	h_score=homogeneity_score(train_label,predict_label)
	c_score=completeness_score(train_label,predict_label)
	r_score=adjusted_rand_score(train_label,predict_label)
	m_score=adjusted_mutual_info_score(train_label,predict_label)
	print h_score,c_score,r_score,m_score

nmf=NMF(n_components=2)
nmf_idf=nmf.fit_transform(X_train_tfidf)

fig=plt.figure()
predict_label=knn.fit_predict(nmf_idf)
predict_label,accu=correct(predict_label,train_label)
plt_label0=nmf_idf[predict_label==0,:]
plt_label1=nmf_idf[predict_label==1,:]
plt.plot(plt_label0[:,0],plt_label0[:,1],'ro',plt_label1[:,0],plt_label1[:,1],'bo')
plt.savefig('nmf-notransform.png')
plt.show()

nmf=NMF(n_components=2)
nmf_idf=nmf.fit_transform(X_train_tfidf)
nmf_idf=non_linear(nmf_idf)
fig=plt.figure()
predict_label=knn.fit_predict(nmf_idf)
predict_label,accu=correct(predict_label,train_label)
h_score=homogeneity_score(train_label,predict_label)
c_score=completeness_score(train_label,predict_label)
r_score=adjusted_rand_score(train_label,predict_label)
m_score=adjusted_mutual_info_score(train_label,predict_label)
print h_score,c_score,r_score,m_score
plt_label0=nmf_idf[predict_label==0,:]
plt_label1=nmf_idf[predict_label==1,:]
plt.plot(plt_label0[:,0],plt_label0[:,1],'ro',plt_label1[:,0],plt_label1[:,1],'bo')
plt.savefig('nmf-logtransform.png')
plt.show()