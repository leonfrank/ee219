The code problem1.py and problem5.py are written in python 2.7.
The result of problem1-4 are returned in problem1.py. The result of problem5-6 are returned in problem5.py